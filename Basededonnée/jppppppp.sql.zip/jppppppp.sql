-- phpMyAdmin SQL Dump
-- version 4.5.4.1
-- http://www.phpmyadmin.net
--
-- Client :  localhost
-- Généré le :  Jeu 05 Décembre 2024 à 17:27
-- Version du serveur :  5.7.11
-- Version de PHP :  5.6.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `jppppppp`
--

-- --------------------------------------------------------

--
-- Structure de la table `contenu`
--

CREATE TABLE `contenu` (
  `id` int(11) NOT NULL,
  `personne_id` int(11) NOT NULL,
  `sujet_id` int(11) NOT NULL,
  `contenu` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `contenu`
--

INSERT INTO `contenu` (`id`, `personne_id`, `sujet_id`, `contenu`) VALUES
(1, 1, 1, 'Pentesting'),
(2, 1, 1, 'SÃ©curitÃ© des rÃ©seaux'),
(3, 1, 1, 'Cryptographie'),
(4, 1, 1, 'Analyse des vulnÃ©rabilitÃ©s'),
(5, 1, 1, 'Forensic'),
(6, 1, 2, 'CompTIA Security+'),
(7, 1, 2, 'CEH'),
(8, 1, 2, 'CISSP'),
(9, 1, 2, 'OSCP'),
(10, 1, 2, 'ISO/IEC 27001 Lead Implementer'),
(11, 2, 1, 'Wireshark'),
(12, 2, 1, 'Pentesting de Site web'),
(13, 2, 1, 'Utilisation de Kali Linux'),
(14, 2, 1, 'Python'),
(15, 2, 1, 'Langage Web : HTML, CSS, JS, PHP, MySQL'),
(16, 2, 2, 'Certification Owasp'),
(17, 2, 2, 'Certification Hacker Ethique'),
(18, 2, 2, 'Certification Osint'),
(19, 2, 2, 'Certification Google Security Certification'),
(20, 2, 2, 'Certification SÃ©curitÃ© Offensive'),
(21, 3, 1, 'Analyse des vulnÃ©rabilitÃ©s'),
(22, 3, 1, 'Gestion des incidents de sÃ©curitÃ©'),
(23, 3, 1, 'SÃ©curisation des infrastructures'),
(24, 3, 1, 'Cryptographie'),
(25, 3, 1, 'CompÃ©tences en DÃ©veloppement'),
(26, 3, 2, 'Microsoft Certified: Security, Compliance, and Identity'),
(27, 3, 2, 'Cisco Certified CyberOps Associate'),
(28, 3, 2, 'GIAC Security Essentials (GSEC)'),
(29, 3, 2, 'CISSP'),
(30, 4, 1, 'Outils de gestion de projet'),
(31, 4, 1, 'Communication digitale'),
(32, 4, 1, 'Programmation (Python, CSS, JS, HTML)'),
(33, 4, 2, 'le MOOC'),
(34, 4, 2, 'BaccalaurÃ©at GÃ©nÃ©ral'),
(35, 5, 1, 'Analyse des vulnÃ©rabilitÃ©s'),
(36, 5, 1, 'Cryptographie'),
(37, 5, 1, 'SÃ©curitÃ© des rÃ©seaux et des portefeuilles'),
(38, 5, 1, 'Gestion des identitÃ©s et des accÃ¨s (IAM)'),
(39, 5, 2, 'CISSP'),
(40, 5, 2, 'CEH'),
(41, 5, 2, 'CISM'),
(42, 5, 2, 'CompTIA Security+'),
(43, 5, 2, 'CISA');

-- --------------------------------------------------------

--
-- Structure de la table `personne`
--

CREATE TABLE `personne` (
  `id` int(11) NOT NULL,
  `nom` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `personne`
--

INSERT INTO `personne` (`id`, `nom`) VALUES
(3, 'Dimitri'),
(4, 'Emeric'),
(2, 'Emil'),
(5, 'Ilyass'),
(1, 'Jassym');

-- --------------------------------------------------------

--
-- Structure de la table `sujet`
--

CREATE TABLE `sujet` (
  `id` int(11) NOT NULL,
  `type` enum('skill','certification') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `sujet`
--

INSERT INTO `sujet` (`id`, `type`) VALUES
(1, 'skill'),
(2, 'certification');

--
-- Index pour les tables exportées
--

--
-- Index pour la table `contenu`
--
ALTER TABLE `contenu`
  ADD PRIMARY KEY (`id`),
  ADD KEY `personne_id` (`personne_id`),
  ADD KEY `sujet_id` (`sujet_id`);

--
-- Index pour la table `personne`
--
ALTER TABLE `personne`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nom` (`nom`);

--
-- Index pour la table `sujet`
--
ALTER TABLE `sujet`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `contenu`
--
ALTER TABLE `contenu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;
--
-- AUTO_INCREMENT pour la table `personne`
--
ALTER TABLE `personne`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT pour la table `sujet`
--
ALTER TABLE `sujet`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `contenu`
--
ALTER TABLE `contenu`
  ADD CONSTRAINT `contenu_ibfk_1` FOREIGN KEY (`personne_id`) REFERENCES `personne` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `contenu_ibfk_2` FOREIGN KEY (`sujet_id`) REFERENCES `sujet` (`id`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
