-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Client :  localhost
-- Généré le :  Jeu 05 Décembre 2024 à 10:26
-- Version du serveur :  5.6.20-log
-- Version de PHP :  7.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `cyberfolio`
--

-- --------------------------------------------------------

--
-- Structure de la table `autres`
--

CREATE TABLE IF NOT EXISTS `autres` (
  `Titre` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `Texte` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `Nom` text NOT NULL,
  `type` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Contenu de la table `autres`
--

INSERT INTO `autres` (`Titre`, `Texte`, `Nom`, `type`) VALUES
('presentation', 'Ã‰tant un Ã©tudiant passionnÃ© de cyber et motivÃ© dâ€™apprendre toujours plus, jâ€™ai dÃ©cidÃ© d''intÃ©grer cette annÃ©e une Ã©cole de cybersÃ©curitÃ© (Guardia Cybersecurity School) Ã  Lyon. Cette premiÃ¨re annÃ©e dans le bachelor â€œdÃ©veloppeur informatique option cybersÃ©curitÃ©â€ va me permettre d''acquÃ©rir des bases solides en culture cyber, Dev SecOps, sÃ©curitÃ© ISR (Infrastructure SystÃ¨me & RÃ©seau) et en rÃ©tro-ingÃ©nierie. Pointilleux et coopÃ©ratif, je recherche activement un stage dans le domaine de la cybersÃ©curitÃ© pour une durÃ©e de 2 Ã  4 mois entre MAI et SEPTEMBRE 2025. Test', 'emile', ''),
('Sapeur-Pompier', 'Apres 6 annees de formation intense en tant que Jeune Sapeur-Pompier, je suis rentrer Sapeur-Pompier Volontaire au centre de secours de Seyssel en septembre 2023.', 'emile', 'activiter'),
('Musique - Accordeon', 'Je fais de la musique depuis maintenant 10 ans dont 6ans en ecole de musique? Je pratique plusieurs instruments mais principalement l''accordeon et le piano.', 'emile', 'activiter'),
('VTT - Enduro', 'Je pratique regulierement le vtt enduro. Une discipline qui consiste Ã  faire des sentiers techniques en descente. J''ai participe Ã  deux competitions une departementale et une rzgionalz', 'emile', 'activiter'),
('Parapente', 'Je pratique le parapente depuis mes 15ans, cela me permet de m''evader.', 'emeric', 'activiter'),
('Ski Freestyle', 'Habitant a la montagne, je pratique le ski freestyle depuis ma plus jeune enfance.', 'emeric', 'activiter'),
('Dessin', 'Je dessin courament des personnages de manga pendant mes temps libres', 'emeric', 'activiter'),
('presentation', 'Je suis dynamique, passionÃ© et toujours trÃ¨s attentifs et investi. DÃ©terminÃ©, sÃ©rieux, autonome\r\net conscient du travail qui\r\nm''attend.\r\nDe par mes divers\r\ncompÃ©tences et expÃ©riences,\r\nje suis persuadÃ© que je serais\r\nun Ã©lÃ©ment moteur au sein de\r\nvotre structure.\r\n\r\n', 'ilyass', ''),
('presentation', 'Je m''appelle Dimitri, j''ai 17 ans et je suis passionnÃ© par le monde du numÃ©rique je suis fascinÃ© par les technologies. Cette curiositÃ© naturelle m''a conduit Ã  m''intÃ©resser de prÃ¨s au dÃ©veloppement web, un domaine oÃ¹ je peux conjuguer crÃ©ativitÃ©, logique, et rÃ©solution de problÃ¨me et Ã  la cyber.', 'dimitri', ''),
('Jeux Video', 'Je suis passione par les jeux videos tels que Minecraft, BrawlStars, Clash Royal et Roblox', 'dimitri', 'activiter'),
('Sport', 'Je pratique le foot depuis plusieurs annees et la lutte que j''ai pratique en club pendant deux ans', 'dimitri', 'activiter'),
('Informatique', 'Je suis passione par l''informatique en general, son histoire et j''aime decouvrir des logiciels, des applications...', 'dimitri', 'activiter'),
('VOYAGE', 'J''aime beaucoup voyager  notamment dans les DOMS mais aussi en Espagne car c''est un tres beau pays.', 'ilyass', 'activiter'),
('Numerique', 'Je suis passione par l''informatique et la tehnologie en general. ', 'ilyass', 'activiter'),
('ART-MARTIAUX', 'Je pratique le Judo depuis 4ans en club et le kenjutsu en autodidacte.', 'ilyass', 'activiter'),
('presentation', 'Passionne par la cybersecurite, je suis etudiant a Guardia School à Lyon. Mon objectif est de renforcer la securite des systemes et de prevenir les cyberattaques grace a des solutions innovantes.', 'jassym', ''),
('Pentest', 'Analyse des vulnérabilités des systèmes.', 'jassym', 'activiter'),
('Script Python\r\n', 'Automatisation des processus de sécurité.', 'jassym', 'activiter'),
('OWASP\r\n', 'Exploitation des failles applicatives.', 'jassym', 'activiter'),
('Participation au Hackathon CyberSec 2024', 'Participation au Hackathon CyberSec 2024', 'jassym', 'evenement'),
('Analyse de sécurité pour un site web fictif (OWASP Bricks)', 'Analyse de sécurité pour un site web fictif (OWASP Bricks)', 'jassym', 'evenement');

-- --------------------------------------------------------

--
-- Structure de la table `competence`
--

CREATE TABLE IF NOT EXISTS `competence` (
  `Competence2` text NOT NULL,
  `Fichier` text NOT NULL,
  `description` text NOT NULL,
  `nom` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Contenu de la table `competence`
--

INSERT INTO `competence` (`Competence2`, `Fichier`, `description`, `nom`) VALUES
('Participation au Hackathon CyberSec 2024', '', '', 'jassym'),
('Analyse de sécurité pour un site web fictif (OWASP)', '', '', 'jassym'),
('BurpSuite', 'uploads/file_67516891740a23.17021078.png', '', 'emile'),
('Git', 'uploads/file_6751696e7b1873.54949143.png', '', 'emile'),
('HashCat', 'uploads/file_6751697fd11517.69254079.png', '', 'emile'),
('HTML', 'uploads/file_6751698c43d4d1.93161812.png', '', 'emile'),
('JavaScript', 'uploads/file_675169984ef876.10232165.png', '', 'emile'),
('Kali Linux', 'uploads/file_675169a5a29915.53519847.png', '', 'emile'),
('MySQL', 'uploads/file_675169b2df8516.81297327.png', '', 'emile'),
('PHP', 'uploads/file_675169bd3bb2b3.41146162.png', '', 'emile'),
('Python', 'uploads/file_675169c88d5e42.52245018.png', '', 'emile'),
('VirtualBox', 'uploads/file_675169d65506f2.99769555.png', '', 'emile'),
('Wireshark', 'uploads/file_675169e3266038.90829829.png', '', 'emile'),
('BurpSuite', 'uploads/file_6751712a86ff99.63921712.png', '', 'emeric'),
('Git', 'uploads/file_6751713981d791.52243904.png', '', 'emeric'),
('HashCat', 'uploads/file_67517145f158c1.19911979.png', '', 'emeric'),
('HTML', 'uploads/file_6751714e306d02.71738272.png', '', 'emeric'),
('JavaScript', 'uploads/file_6751715f1435f4.58009622.png', '', 'emeric'),
('MySQL', 'uploads/file_67517169bc7808.26269785.png', '', 'emeric'),
('PHP', 'uploads/file_67517171bd9029.07323420.png', '', 'emeric'),
('Python', 'uploads/file_6751717b969893.24875272.png', '', 'emeric'),
('VirtualBox', 'uploads/file_67517185455f04.47382365.png', '', 'emeric'),
('Wireshark', 'uploads/file_6751718eca1bd2.74411551.png', '', 'emeric'),
('BurpSuite', 'uploads/file_675176cf47b577.75600439.png', '', 'dimitri'),
('JavaScript', 'uploads/file_675176de10f2f3.25835770.png', '', 'dimitri'),
('HTML', 'uploads/file_67517700e93551.87207054.png', '', 'dimitri'),
('Python', 'uploads/file_6751770dc6efb4.42621640.png', '', 'dimitri'),
('BurpSuite', 'uploads/file_67517f4929e357.30317132.png', '', 'ilyass'),
('Git', 'uploads/file_67517f52bd61d8.10125732.png', '', 'ilyass'),
('HashCat', 'uploads/file_67517f5dbad857.75248902.png', '', 'ilyass'),
('HTML', 'uploads/file_67517f6777cda7.27576529.png', '', 'ilyass'),
('JavaScript', 'uploads/file_67517f717bf275.66209969.png', '', 'ilyass'),
('Kali Linux', 'uploads/file_67517f7b889842.52764847.png', '', 'ilyass'),
('MySQL', 'uploads/file_67517f84c62624.61098918.png', '', 'ilyass'),
('PHP', 'uploads/file_67517f8d16b167.91975914.png', '', 'ilyass'),
('Python', 'uploads/file_67517f98cdfa92.38270889.png', '', 'ilyass'),
('VirtualBox', 'uploads/file_67517fa3b84310.38258305.png', '', 'ilyass'),
('Wireshark', 'uploads/file_67517fad00c710.22972843.png', '', 'ilyass');

-- --------------------------------------------------------

--
-- Structure de la table `competence2`
--

CREATE TABLE IF NOT EXISTS `competence2` (
  `Competence` text NOT NULL,
  `Description` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `experience`
--

CREATE TABLE IF NOT EXISTS `experience` (
`ID` int(11) NOT NULL,
  `Titre` text NOT NULL,
  `Date1` text NOT NULL,
  `Texte` text NOT NULL,
  `Competence1` text NOT NULL,
  `Competence2` int(11) NOT NULL,
  `Competence3` int(11) NOT NULL,
  `Nom` text NOT NULL
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=27 ;

--
-- Contenu de la table `experience`
--

INSERT INTO `experience` (`ID`, `Titre`, `Date1`, `Texte`, `Competence1`, `Competence2`, `Competence3`, `Nom`) VALUES
(20, 'EmployÃ© en logistique', 'ChÃªne-en-semine (74), AOÃ›T 2022 ', '<strong>Emploi Saisonnier</strong><br>\r\nMarchÃ© Pernoud est une entreprise local de vente de produits frais. <br>\r\n-Logistique et organisation des entrepÃ´ts  <br>\r\n-Gestion des dÃ©chets (carton, aliment avariÃ©â€¦) <br>\r\n-PrÃ©paration Ã  lâ€™export de marchandise  <br>\r\n-Tri des emballages alimentaires', 'a', 0, 0, 'emile'),
(19, 'Agent polyvalent des services techniques', 'Mairie Seyssel (01) - Juillet Ã  Septembre 2024', '<strong>Emploi Saisonnier</strong><br> \r\n- Entretien des espaces verts (DÃ©broussailleuse, Arrosage, Tondeuseâ€¦)<br> \r\n- Nettoyage des rues et routes<br> \r\n- Responsable de la propretÃ© des lieux publics<br> \r\n- Entretien des Ã©quipements mis Ã  la disposition du public<br> ', 'a', 0, 0, 'emile'),
(21, 'Animateur Enfant', 'Du 10/08/21 au 31/09/2023', 'J''ai du dans ce travail cencevoir des activites ludiques et interessent pour les enfants, tout en securisent l''environnement. Et ce travail m''a permit d''apprendre le travail d''equipe', 'a', 0, 0, 'emeric'),
(22, 'Animateur Adulte et Ingenieur son', 'Du 06/07/24 au 31/08/24', 'J''ai ete charge d''entretenir le materiel son au sein de l''entreprise village club du soleil. Et charger du bon fonctionnement du materiel pendant les spectacles animateurs', 'a', 0, 0, 'emeric'),
(23, 'Orange Cyberdefense', 'Du 01/07/2024 au 31/09/2024', 'Jâ€™ai rejoint lâ€™entreprise Orange Cyber,durant 3 mois jâ€™ai participe Ã  la mise en place et a l''amÃ©lioration de la politique de securite des systemes d''information. Mon role principal consistait a surveiller les reseaux et les systemes pour detecter les menaces et les vulnerabilites. Jâ€™ai Ã©galement mene des analyses de risques, cree des rapports de securite et mis en Å“uvre des solutions de protection contre les attaques. En collaboration avec lâ€™equipe de developpement, jâ€™ai assure la mise en Å“uvre de correctifs de securite pour les applications et participe Ã  la formation des utilisateurs pour prevenir les incidents de securitÃ©.', 'aa', 0, 0, 'dimitri'),
(24, 'Anchor Badian Studio', '24-03-2024', '<strong>ENTREPREUNEUR (CHEF DE PROJET)</strong><br>\r\nLancement complÃ¨te d''un Studio multimÃ©dia<br>\r\nCommunity manager : gestion des rÃ©seaux sociaux<br>\r\nGestion de serveur Gaming Role Play<br>\r\nCrÃ©ation de contenu audiovisuel<br>\r\nProduction de Livres\r\n', 'a', 0, 0, 'ilyass'),
(25, 'Fitissimo', '12-12-2024', '<strong>CHARGÃ‰E DE COMMUNICATION</strong><br>\r\n- RÃ©alisation kakÃ©monos, banderoles, affiches, post sur les rÃ©seaux sociaux.<br>\r\n- Mise en place d''un jeu concours : prospection des lots<br>\r\n- Service accueil et photographie<br>', 'a', 0, 0, 'ilyass'),
(26, 'King Jouet', '12-12-2024', '<strong>CHARGÃ‰ DE COMMUNICATION</strong><br>\r\nRÃ©alisation plaquette commerciale, logo, affiches ...<br>\r\nOrganisation d''Ã©vÃ©nements (cÃ©rÃ©monie, tournoi de pÃ©tanque)<br>\r\nGestion administration, site web, rÃ©seaux sociaux, publipostages<br>\r\nInterviews sur le terrain, journaliste sportive, montage, publication\r\n', 'a', 0, 0, 'ilyass');

-- --------------------------------------------------------

--
-- Structure de la table `projet`
--

CREATE TABLE IF NOT EXISTS `projet` (
`ID` int(11) NOT NULL,
  `Titre` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `Date1` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `Texte` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `Competence1` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `Competence2` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `Competence3` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `Fichier` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `Nom` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=44 ;

--
-- Contenu de la table `projet`
--

INSERT INTO `projet` (`ID`, `Titre`, `Date1`, `Texte`, `Competence1`, `Competence2`, `Competence3`, `Fichier`, `Nom`) VALUES
(1, 'Pentest', 'Octobre 2024', 'AZZABI Arij nous a introduit la cybersecurite avec un premier projet de Pentest. <br>                Connaissances :<br>                - Outil de Collaboration (Git)<br>                - Utilisation de Kali Linux a l''aide d''une machine virtuel<br>                - Hebergement un site PHP en localhost (Uwamp, Docker)<br>                - Decouverte d''outil de Pentest (BurpSuit)<br>                - Injection SQL, Modification des requetes http, Broken Access Control, Inclusion de Fichier<br><br>                                Missions :<br>                - S''entrainer sur un site en localhost (Owasp Bricks)<br>                - Produire un rapport de test d''intrusion', 'Injection SQL', 'BURPSuit', 'Owasp', '../folder/emile/pentest.pdf', 'emile'),
(40, 'OSINT', 'Novembre 2024', 'Julien Metayer etait notre intervenant a Guardia Cyber Security School pour notre projet OSINT.<br>\r\nConnaissances :<br>\r\n- Decouverte de l''OSINT<br>\r\n- Cadre legal de l''OSINT<br>\r\n- Utilisation des outils de recherches<br>\r\n- Rechercher des informations sur le WEB en etant Anonyme <br><br>\r\n\r\nMissions :<br>\r\n- Rechercher des informations sur une entreprise<br>\r\n- Rechercher des informations sur une Image', 'OSINT', 'GeoINT', 'Imint', 'uploads/file_67517014a6fb15.58636261.txt', 'emile'),
(38, 'OSINT', 'Novembre 2024', 'Julien Metayer etait notre intervenant a Guardia Cyber Security School pour notre projet OSINT.<br>\r\nConnaissances :<br>\r\n- Decouverte de l''OSINT<br>\r\n- Cadre legal de l''OSINT<br>\r\n- Utilisation des outils de recherches<br>\r\n- Rechercher des informations sur le WEB en etant Anonyme <br><br>\r\n\r\nMissions :<br>\r\n- Rechercher des informations sur une entreprise<br>\r\n- Rechercher des informations sur une Image', 'OSINT', 'GeoINT', 'Imint', 'uploads/file_67517014a6fb15.58636261.txt', 'dimitri'),
(37, 'OSINT', 'Novembre 2024', 'Julien Metayer etait notre intervenant a Guardia Cyber Security School pour notre projet OSINT.<br>\r\nConnaissances :<br>\r\n- Decouverte de l''OSINT<br>\r\n- Cadre legal de l''OSINT<br>\r\n- Utilisation des outils de recherches<br>\r\n- Rechercher des informations sur le WEB en etant Anonyme <br><br>\r\n\r\nMissions :<br>\r\n- Rechercher des informations sur une entreprise<br>\r\n- Rechercher des informations sur une Image', 'OSINT', 'GeoINT', 'Imint', 'uploads/file_67517014a6fb15.58636261.txt', 'emeric'),
(39, 'OSINT', 'Novembre 2024', 'Julien Metayer etait notre intervenant a Guardia Cyber Security School pour notre projet OSINT.<br>\r\nConnaissances :<br>\r\n- Decouverte de l''OSINT<br>\r\n- Cadre legal de l''OSINT<br>\r\n- Utilisation des outils de recherches<br>\r\n- Rechercher des informations sur le WEB en etant Anonyme <br><br>\r\n\r\nMissions :<br>\r\n- Rechercher des informations sur une entreprise<br>\r\n- Rechercher des informations sur une Image', 'OSINT', 'GeoINT', 'Imint', 'uploads/file_67517014a6fb15.58636261.txt', 'ilyass'),
(41, 'Pentest', 'Octobre 2024', 'AZZABI Arij nous a introduit la cybersecurite avec un premier projet de Pentest. <br>                Connaissances :<br>                - Outil de Collaboration (Git)<br>                - Utilisation de Kali Linux a l''aide d''une machine virtuel<br>                - Hebergement un site PHP en localhost (Uwamp, Docker)<br>                - Decouverte d''outil de Pentest (BurpSuit)<br>                - Injection SQL, Modification des requetes http, Broken Access Control, Inclusion de Fichier<br><br>                                Missions :<br>                - S''entrainer sur un site en localhost (Owasp Bricks)<br>                - Produire un rapport de test d''intrusion', 'Injection SQL', 'BURPSuit', 'Owasp', '../folder/emile/pentest.pdf', 'emeric'),
(42, 'Pentest', 'Octobre 2024', 'AZZABI Arij nous a introduit la cybersecurite avec un premier projet de Pentest. <br>                Connaissances :<br>                - Outil de Collaboration (Git)<br>                - Utilisation de Kali Linux a l''aide d''une machine virtuel<br>                - Hebergement un site PHP en localhost (Uwamp, Docker)<br>                - Decouverte d''outil de Pentest (BurpSuit)<br>                - Injection SQL, Modification des requetes http, Broken Access Control, Inclusion de Fichier<br><br>                                Missions :<br>                - S''entrainer sur un site en localhost (Owasp Bricks)<br>                - Produire un rapport de test d''intrusion', 'Injection SQL', 'BURPSuit', 'Owasp', '../folder/emile/pentest.pdf', 'ilyass'),
(43, 'Pentest', 'Octobre 2024', 'AZZABI Arij nous a introduit la cybersecurite avec un premier projet de Pentest. <br>                Connaissances :<br>                - Outil de Collaboration (Git)<br>                - Utilisation de Kali Linux a l''aide d''une machine virtuel<br>                - Hebergement un site PHP en localhost (Uwamp, Docker)<br>                - Decouverte d''outil de Pentest (BurpSuit)<br>                - Injection SQL, Modification des requetes http, Broken Access Control, Inclusion de Fichier<br><br>                                Missions :<br>                - S''entrainer sur un site en localhost (Owasp Bricks)<br>                - Produire un rapport de test d''intrusion', 'Injection SQL', 'BURPSuit', 'Owasp', '../folder/emile/pentest.pdf', 'dimitri');

--
-- Index pour les tables exportées
--

--
-- Index pour la table `experience`
--
ALTER TABLE `experience`
 ADD PRIMARY KEY (`ID`);

--
-- Index pour la table `projet`
--
ALTER TABLE `projet`
 ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `experience`
--
ALTER TABLE `experience`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT pour la table `projet`
--
ALTER TABLE `projet`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=44;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
